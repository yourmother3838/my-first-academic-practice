const cardsData = [
  {
    rating: "4.9",
    country: "Italy",
    image: "./images/venice.webp",
    title: "Venice Tour",
    price: "$820",
    description: "Romantic canals and beautiful architecture."
  },

  {
    rating: "4.7",
    country: "Japan",
    image: "./images/jappan.webp",
    title: "Tokyo Lights",
    price: "$910",
    description: "Night city views and modern culture."
  },

  {
    rating: "4.8",
    country: "Turkey",
    image: "./images/ca[.jpg",
    title: "Cappadocia",
    price: "$990",
    description: "Balloon flights and mountain landscapes."
  },

  {
    rating: "4.5",
    country: "France",
    image: "./images/i.jpg",
    title: "Paris Dream",
    price: "$870",
    description: "The city of love and elegant streets."
  },

  {
    rating: "4.6",
    country: "Indonesia",
    image: "./images/bali.webp",
    title: "Bali Beach",
    price: "$760",
    description: "Warm ocean and tropical отдых."
  },

  {
    rating: "4.7",
    country: "Norway",
    image: "./images/norway.webp",
    title: "Northern Lights",
    price: "$1200",
    description: "Snowy mountains and magical skies."
  },

  {
    rating: "4.8",
    country: "Egypt",
    image: "./images/egypt.webp",
    title: "Pyramids",
    price: "$680",
    description: "Ancient history and desert adventures."
  },

  {
    rating: "4.4",
    country: "Brazil",
    image: "./images/brazil.webp",
    title: "Rio Travel",
    price: "$890",
    description: "Sunny beaches and festivals."
  },

  {
    rating: "4.9",
    country: "Switzerland",
    image: "./images/swi.webp",
    title: "Alpine Escape",
    price: "$1350",
    description: "Luxury mountain vacation."
  },

  {
    rating: "4.5",
    country: "India",
    image: "./images/india.webp",
    title: "Taj Mahal",
    price: "$590",
    description: "Historic places and colorful culture."
  },

  {
    rating: "4.6",
    country: "Canada",
    image: "./images/canada.jpg",
    title: "Forest Camp",
    price: "$740",
    description: "Lakes, forests and peaceful nature."
  },

  {
    rating: "4.8",
    country: "Greece",
    image: "./images/greece.webp",
    title: "Santorini",
    price: "$980",
    description: "White houses and blue sea views."
  },

  {
    rating: "4.7",
    country: "Morocco",
    image: "./images/marocco.webp",
    title: "Sahara Trip",
    price: "$720",
    description: "Camel rides and desert nights."
  },

  {
    rating: "4.9",
    country: "Maldives",
    image: "./images/maldives.webp",
    title: "Ocean Paradise",
    price: "$1600",
    description: "Crystal water and luxury villas."
  },

  {
    rating: "4.6",
    country: "Iceland",
    image: "./images/iceland.webp",
    title: "Frozen World",
    price: "$1100",
    description: "Volcanoes, waterfalls and glaciers."
  },
   {
    rating: "4.6",
    country: "Russia",
    image: "./images/moskow.webp",
    title: "Moskow",
    price: "$1100",
    description: "Volcanoes, waterfalls and glaciers."
  }
];

const cardBox = document.getElementById("cardBox");

cardsData.forEach((card) => {
  cardBox.innerHTML += `
  
    <div class="card">

      <div class="card-top">

        <div class="img-btn">
          <div class="star-circle">
            <i class="fa-solid fa-star"></i>
          </div>

          <span>${card.rating}</span>
        </div>

        <div class="location">
          <i class="fa-solid fa-location-dot"></i>
          ${card.country}
        </div>

        <img src="${card.image}" alt="${card.title}" />

      </div>

      <div class="card-bottom">

        <div class="card-imp">
          <div class="card-title">${card.title}</div>
          <div class="card-price">${card.price}</div>
        </div>

        <div class="card-description">
          <p>${card.description}</p>
        </div>

      </div>

    </div>

  `;
});