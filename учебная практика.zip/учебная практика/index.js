
const burgerBtn = document.getElementById('burgerBtn');
const navMenu = document.getElementById('navMenu');

if (burgerBtn && navMenu) {
  burgerBtn.addEventListener('click', () => {
    navMenu.classList.toggle('open');
  });

  navMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => navMenu.classList.remove('open'));
  });
}


const cardBox = document.getElementById('cardBox');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');

if (cardBox && prevBtn && nextBtn) {
  let currentIndex = 0;

  function getVisibleCount() {
    const wrapperWidth = cardBox.parentElement.clientWidth;
    const cardWidth = cardBox.children[0]?.offsetWidth || 421;
    const gap = 30;
    return Math.floor((wrapperWidth + gap) / (cardWidth + gap));
  }

  function getCardStep() {
    const card = cardBox.children[0];
    if (!card) return 451;
    return card.offsetWidth + 30;
  }

  function getTotalCards() {
    return cardBox.children.length;
  }

  function updateSlider() {
    const step = getCardStep();
    const visible = getVisibleCount();
    const max = Math.max(0, getTotalCards() - visible);

    currentIndex = Math.max(0, Math.min(currentIndex, max));
    cardBox.style.transform = `translateX(-${currentIndex * step}px)`;

   
    prevBtn.classList.toggle('disabled', currentIndex === 0);
    nextBtn.classList.toggle('disabled', currentIndex >= max);
  }


  prevBtn.addEventListener('click', () => {
    currentIndex--;
    updateSlider();
  });

  nextBtn.addEventListener('click', () => {
    currentIndex++;
    updateSlider();
  });


  let touchStartX = 0;
  let touchEndX = 0;

  cardBox.addEventListener('touchstart', (e) => {
    touchStartX = e.changedTouches[0].screenX;
  }, { passive: true });

  cardBox.addEventListener('touchend', (e) => {
    touchEndX = e.changedTouches[0].screenX;
    const diff = touchStartX - touchEndX;

    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        currentIndex++;
      } else {
        currentIndex--;
      }
      updateSlider();
    }
  }, { passive: true });


  window.addEventListener('resize', () => {
    updateSlider();
  });


  updateSlider();
}
